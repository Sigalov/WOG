from Live import welcome, load_game

welcome('Oleg')
load_game()